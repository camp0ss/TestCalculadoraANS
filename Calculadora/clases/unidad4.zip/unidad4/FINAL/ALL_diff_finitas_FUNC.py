import math
import sympy as sp

x = sp.Symbol('x') 

def ff(func, evaluator): 
    solution = func.evalf(subs={"x":evaluator})
    return solution

def error_calculator(func,estimate_value, searched_value):
    real_value = sp.diff(func,x,1)
    real_value.expand()
    real_value = real_value.subs(x, searched_value)
    e = abs(real_value-estimate_value)
    er = abs(e/real_value)
    er100 = abs((e/real_value)*100)
    errors = {"Real Value": real_value ,"e" : e ,"er" : er , "er100 " : er100}
    return errors

def first_forward_diff(func, h, point):
    solution_FDF = (ff(func,(point+h)) - ff(func,(point)))/(h)
    print("\nSolucion primer diferencia adelante de ",func ," en el punto ",point ," es ", solution_FDF)
    print("Errors:", error_calculator(func,solution_FDF, point))

def first_backward_diff(func, h, point):
    solution_FDB = (-ff(func,(point-h)) + ff(func,(point)))/(h)
    print("\nSolucion primer diferencia atras de ",func ," en el punto ",point ," es ", solution_FDB)
    print("Errors:", error_calculator(func,solution_FDB, point))

def second_forward_diff(func, h , point):
    solution_SDF = (-ff(func,(point+(2*h)))+4*(ff(func,(point+h)))-3*(ff(func,(point))))/(2*h)
    print("\nSolucion segunda diferencia adelante de ",func ," en el punto ",point ," es ", solution_SDF)
    print("Errors:", error_calculator(func,solution_SDF, point))

def second_backward_diff(func, h , point):
    solution_SDB = (+ff(func,(point-(2*h)))-4*(ff(func,(point-h)))+3*(ff(func,(point))))/(2*h)
    print("\nSolucion segunda diferencia atras de ",func ," en el punto ",point ," es ", solution_SDB)
    print("Errors:", error_calculator(func,solution_SDB, point))

def central_second_order(func, h , point):
    solution_CSO = ((ff(func,(point+h)) - ff(func,(point-h))))/(2*h)
    print("\nSolucion segunda diferencia central de ",func ," en el punto ",point ," es ", solution_CSO)
    print("Errors:", error_calculator(func,solution_CSO, point))    

def central_fourth_order(func, h , point):
    solution_CFO = (  -(ff(func,(point+(2*h)))) + (8*(ff(func,(point+h)))) - (8*(ff(func,(point-h)))) + (ff(func,(point-(2*h)))) )/()
    print("\nSolucion segunda diferencia central de ",func ," en el punto ",point ," es ", solution_CFO)
    print("Errors:", error_calculator(func,solution_CFO, point))    

def three_points_0(func, h , point):
    solution_TP0 = ((ff(func,(point+h)) - ff(func,(point-h))))/(2*h)
    print("\nSolucion formula de 3 puntos version 1 de ",func ," en el punto ",point ," es ", solution_TP0)
    print("Errors:", error_calculator(func,solution_TP0, point))    

def three_points_1(func, h , point):
    solution_TP1 = (-ff(func,(point+(2*h)))+4*(ff(func,(point+h)))-3*(ff(func,(point))))/(2*h)
    print("\nSolucion formula de 3 puntos version 2 de ",func ," en el punto ",point ," es ", solution_TP1)
    print("Errors:", error_calculator(func,solution_TP1, point))



uwu = sp.sympify ("log(x)")
h = 0.1
value = 5
first_forward_diff(uwu, h, value)
second_forward_diff(uwu, h,value)

h= 0.05
first_backward_diff(uwu, h, value)
second_backward_diff(uwu, h, value)

central_second_order(1.3,0.1)