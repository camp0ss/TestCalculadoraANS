import math
import sympy as sp

x = sp.Symbol('x') 

dic = {1.2:2.372895,
       1.3:2.308785,
       1.4:2.245066             }


def ff(  evaluator): 
    evaluator = round(evaluator,5)
    #print(evaluator)
    uwu = dic[evaluator]
    return uwu

real_value = -0.639962


def error_calculator( estimate_value):
    e = abs(real_value-estimate_value)
    er = abs(e/real_value)
    er100 = abs((e/real_value)*100)
    errors = {"Real Value": real_value ,"e" : e ,"er" : er , "er100 " : er100}
    return errors

def first_forward_diff(  h, point):
    solution_FDF = (ff( (point+h)) - ff( (point)))/(h)
    print("\nSolucion primer diferencia adelante de ", "una tabla dada" ," en el punto ",point ," es ", solution_FDF)
    print("Errors:", error_calculator( solution_FDF))

def first_backward_diff(  h, point):
    solution_FDB = (-ff( (point-h)) + ff( (point)))/(h)
    print("\nSolucion primer diferencia atras de ", "una tabla dada" ," en el punto ",point ," es ", solution_FDB)
    print("Errors:", error_calculator( solution_FDB))

def second_forward_diff(  h , point):
    solution_SDF = (-ff( (point+(2*h)))+4*(ff( (point+h)))-3*(ff( (point))))/(2*h)
    print("\nSolucion segunda diferencia adelante de ", "una tabla dada" ," en el punto ",point ," es ", solution_SDF)
    print("Errors:", error_calculator( solution_SDF))

def second_backward_diff(  h , point):
    solution_SDB = (+ff( (point-(2*h)))-4*(ff( (point-h)))+3*(ff( (point))))/(2*h)
    print("\nSolucion segunda diferencia atras de ", "una tabla dada" ," en el punto ",point ," es ", solution_SDB)
    print("Errors:", error_calculator( solution_SDB))

def central_second_order(  h , point):
    solution_CSO = ((ff( (point+h)) - ff( (point-h))))/(2*h)
    print("\nSolucion segunda diferencia central de ", "una tabla dada" ," en el punto ",point ," es ", solution_CSO)
    print("Errors:", error_calculator( solution_CSO))    

def central_fourth_order(  h , point):
    solution_CFO = (  -(ff( (point+(2*h)))) + (8*(ff( (point+h)))) - (8*(ff( (point-h)))) + (ff( (point-(2*h)))) )/()
    print("\nSolucion segunda diferencia central de ", "una tabla dada" ," en el punto ",point ," es ", solution_CFO)
    print("Errors:", error_calculator( solution_CFO))    

def three_points_0(  h , point):
    solution_TP0 = ((ff( (point+h)) - ff( (point-h))))/(2*h)
    print("\nSolucion formula de 3 puntos version 1 de ", "una tabla dada" ," en el punto ",point ," es ", solution_TP0)
    print("Errors:", error_calculator( solution_TP0))    

def three_points_1( h , point):
    solution_TP1 = (-ff( (point+(2*h)))+4*(ff( (point+h)))-3*(ff( (point))))/(2*h)
    print("\nSolucion formula de 3 puntos version 2 de ", "una tabla dada" ," en el punto ",point ," es ", solution_TP1)
    print("Errors:", error_calculator(solution_TP1))


central_second_order(0.1, 1.3)