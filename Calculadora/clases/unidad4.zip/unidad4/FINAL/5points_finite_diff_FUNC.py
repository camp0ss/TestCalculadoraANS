import sympy as sp
from sympy.core.sympify import sympify
x = sp.Symbol('x') 

def ff(func, evaluator): 
    solution = func.evalf(subs={"x":evaluator})
    return solution

def data_displayer(func,estimate_value, searched_value, formula):
    real_value = sp.diff(func,x,1)
    real_value.expand()
    real_value = real_value.subs(x, searched_value)
    e = abs(real_value-estimate_value)
    er = abs(e/real_value)
    er100 = abs((e/real_value)*100)
    #print(real_value)
    data = {"Formula: ": formula,"Calculated Value:": estimate_value,"e" : e ,"er" : er , "er100 " : er100}
    return data

def five_points_diff(func, h, point):

    FFD = list()
    FFD.append((1/(12*h))*(-25*ff(func,point)+48*ff(func,(point+h))-36*ff(func,(point+2*h))+16*ff(func,(point+3*h))-3*ff(func,(point+4*h))))
    FFD.append((1/(12*h))*(-3*ff(func,(point-h))-10*ff(func,point)+18*ff(func,(point+h))-6*ff(func,(point+2*h))+ff(func,(point+3*h)))) 
    FFD.append((1/(12*h))*(ff(func,(point-2*h))-8*ff(func,(point-h))+8*ff(func,(point+h))-ff(func,(point+2*h)))) 
    FFD.append((1/(12*h))*(4*ff(func,(point-3*h))+6*ff(func,(point+2*h))-8*ff(func,(point-h))+34*ff(func,point)+3*ff(func,(point+h))+34*ff(func,(point+2*h)))) 
    FFD.append((1/(12*h))*(ff(func,(point-4*h))-3*ff(func,(point-3*h))+4*ff(func,(point-2*h))-36*ff(func,(point-h))+25*ff(func,point)))
    
    formula = 1
    for x in FFD:
        print("Results:", data_displayer(func,x, point, formula))
        formula = formula + 1

uwu = sympify("log(x)*tan(x)")
five_points_diff(uwu, 0.1, 4.2)