
from time import sleep

import numpy as np
np.set_printoptions(precision=9)

print("Metodo de Richardson\n")


lista_de_listas=[ [1.428058262], 
                  [1.428541128], 
                  [1.428569561],
                  [1.428571312],
                  [1.428571421]
                  ]

a = np.array(lista_de_listas)
print("Valores en la entrada:\n" ,a)

#activa prints para ver los valores 
debug = True


def calcular_h (nivelprevio, k, i):
    sleep(0.05)
    if debug:
        print("IMPRIMIENDO ENTRADA DE LA FUNCION IMPORTANTE:\n",nivelprevio)

    k = k -1
    i = i -1
    
    valorparak = (((4**k)*(nivelprevio[(i+1)]))/((4**k)-1))-(1*(nivelprevio[i])/((4**k)-1))
    
    if debug:
        print("i+1 = ",nivelprevio[(i+1)] )
        print("i = ",nivelprevio[i] )
        print("Valor: ", valorparak)

    return valorparak


def levelgenerator(nivelprevio,numeronivelacrear,iteraciones):
    sleep(0.05)
    listita = list()
    cantidad = len(nivelprevio)
    for xd in range(1, iteraciones+1):
        listita.append(calcular_h(nivelprevio,numeronivelacrear,xd))
    for xd in range(cantidad-iteraciones):
        listita.append(0)

    if debug:
        print("imprimiendo listita", listita)

    listafinal = []
    for i in range(cantidad):
        listafinal.append([])
        listafinal[i].append(listita[i])
    return listafinal


contador = 0
def mainsito(nivel,matriz):
    iteraciones = nivel 
    for uwu in range (nivel):
        iteraciones = iteraciones - 1
        listak = list ()        
        listak = matriz[:,uwu]
        newlevel = levelgenerator(listak,(uwu+2),iteraciones)
        matriz = np.append(matriz, newlevel, axis=1)
    sleep(0.07)
    #print(AR13)
    sleep(0.03)
    print("\n\nRespuesta:\n",matriz)

mainsito(5,a)


