import numpy as np
print("Metodo de Richardson")

lista_de_listas=[ [6.1405], 
                  [-0.910675 ], 
                  [-0.912053125]]

a = np.array(lista_de_listas)
print(a)



#formula que genera los valores para las nuevas columnas
def funcionimportante (nivelprevio, k, i):
    print("IMPRIMIENDO ENTRADA DE LA FUNCION IMPORTANTE:\n",nivelprevio)
    k = k -1
    i = i -1
    print("i+1 = ",nivelprevio[(i+1)] )
    print("i = ",nivelprevio[i] )
    valorparak = (((4**k)*(nivelprevio[(i+1)]))/((4**k)-1))-(1*(nivelprevio[i])/((4**k)-1))
    print("Valor: ", valorparak)

    return valorparak

#funcion que genera las nuevas clumnas
def generadordecolumnas(nivelprevio,numeronivelacrear,iteraciones):
    listita = list()
    cantidad = len(nivelprevio)
    for xd in range(1, iteraciones+1):
        listita.append(funcionimportante(nivelprevio,numeronivelacrear,xd))
    for xd in range(cantidad-iteraciones):
        listita.append(0)
    print("imprimiendo listita", listita)
    listafinal = []
    for i in range(cantidad):
        listafinal.append([])
        listafinal[i].append(listita[i])
    print("columna generada = \n", listafinal)
    return listafinal


contador = 0
def mainsito(nivel,matriz):
    iteraciones = nivel 
    for uwu in range (nivel):
        iteraciones = iteraciones - 1
        listak = list ()        
        listak = matriz[:,uwu]
        newlevel = generadordecolumnas(listak,(uwu+2),iteraciones)
        matriz = np.append(matriz, newlevel, axis=1)
    print(matriz)

mainsito(3,a)


