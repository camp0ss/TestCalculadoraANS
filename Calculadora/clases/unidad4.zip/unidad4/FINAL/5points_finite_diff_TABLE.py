import sympy as sp
from sympy.core.sympify import sympify
x = sp.Symbol('x') 

#no funciona, no hay ejemplo para comprobarlo pero en teoria esta weñop


dic = {1.2:2.372895,
       1.3:2.308785,
       1.4:2.245066,
       1.5:2.182179            }


def ff(  evaluator): 
    evaluator = round(evaluator,5)
    #print(evaluator)
    uwu = dic[evaluator]
    return uwu

real_value = -0.639962

def data_displayer( estimate_value, searched_value, formula):
    real_value = sp.diff( x,1)
    real_value.expand()
    real_value = real_value.subs(x, searched_value)
    e = abs(real_value-estimate_value)
    er = abs(e/real_value)
    er100 = abs((e/real_value)*100)
    #print(real_value)
    data = {"Formula: ": formula,"Calculated Value:": estimate_value,"e" : e ,"er" : er , "er100 " : er100}
    return data

def five_points_diff(  h, point):

    FFD = list()
    FFD.append((1/(12*h))*(-25*ff( point)+48*ff( (point+h))-36*ff( (point+2*h))+16*ff( (point+3*h))-3*ff( (point+4*h))))
    FFD.append((1/(12*h))*(-3*ff( (point-h))-10*ff( point)+18*ff( (point+h))-6*ff( (point+2*h))+ff( (point+3*h)))) 
    FFD.append((1/(12*h))*(ff( (point-2*h))-8*ff( (point-h))+8*ff( (point+h))-ff( (point+2*h)))) 
    FFD.append((1/(12*h))*(4*ff( (point-3*h))+6*ff( (point+2*h))-8*ff( (point-h))+34*ff( point)+3*ff( (point+h))+34*ff( (point+2*h)))) 
    FFD.append((1/(12*h))*(ff( (point-4*h))-3*ff( (point-3*h))+4*ff( (point-2*h))-36*ff( (point-h))+25*ff( point)))
    
    formula = 1
    for x in FFD:
        print("Results:", data_displayer( x, point, formula))
        formula = formula + 1

uwu = sympify("log(x)*tan(x)")

five_points_diff(0.1, 1.3)