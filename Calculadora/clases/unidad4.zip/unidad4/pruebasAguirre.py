from integracion import TrapecioIntervalo, Trapecio, SimpsonTercio, SimpTercIntervalo, SimpOctavo, SimpOctIntervalo,SimpAdaptativo
from integracionListas import IntegracionNum
from rosemberg import Rosemberg

import math
from sympy.parsing.sympy_parser import parse_expr


#Integral doble:
funcion = parse_expr("(x*y)**(1/2)")
aver = TrapecioIntervalo(0, 4, 4, funcion, "y")
data = aver.resultado()
funcion = parse_expr(str(data["integral"]))
aver = TrapecioIntervalo(0, 1, 4, funcion)
print(aver.resultado())

#Simpson 3/8 simple:
funcion = parse_expr("cos(x)+2*sin(x)")
aver = SimpOctavo(0, (math.pi/2), funcion)
print("Simpson 3/8: ",aver.resultado())

#Simpson 3/8 compuesto:
funcion = parse_expr("cos(x)+2*sin(x)")
aver = SimpOctIntervalo(0, (math.pi/2),6 ,funcion)
print("Simpson 3/8 compuesto: ",aver.resultado())

#Rosemberg:
funcion = parse_expr("cos(x)+2*sin(x)")
aver = Rosemberg(0, (math.pi/2), 5, funcion)
print("Rosemberg: ",aver.resultado())

##Simpson Adaptativo:
funcion = parse_expr("cos(x)+2*sin(x)")
aver = SimpAdaptativo(0 , (math.pi/2), 0.3, funcion)
print("Simpson Adaptivo: ",aver.resultado())